#! /bin/bash
echo "grabbing the newest version..."
sshpass -p "R11h2B%3blu3bulb!" scp kclo224@kclo224.netlab.uky.edu:~/CS485G/Project_5/*.c ./
echo "got it!"
