#include "csapp.h"

#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 1024
#define KEY_BYTES 4

int retval; //global error return value, set by whatever the most recent error is

int mcput(char * filename, int connectfd){

	int fd;
	printf("RECEIVED FILENAME: %s\n", filename);

	fd = open(filename, O_RDWR );

	int n;
	rio_t rio;
 	char buf[MAXLINE];

	//change to file name of the wanted file
	Rio_readinitb(&rio, connectfd);
 	while((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0)
		Rio_writen(fd, buf, n);
	close(fd);
	
	return 0;	
}

int mcget();
void deleteFile();
void listFiles();
int validate(int secretKey, int keyUser){
	int accept = 1;

	if ( (keyUser == secretKey)){
		printf("VALID\n");
		accept = 0;
	};
	
	
	return accept;
}

void application(int connectfd, int secretKey ){
	unsigned int keyUser, typeRequest;
	char input[MAX_SIZE];
	unsigned int rawNetBytes = 0;
	unsigned int rawTypeReq = 0;
	char *rawInput;
	int valid;
	//We store the various fields from Rio in here. Otherwise we would use the lowercase Rio_readinitb
	rio_t rioIn;

	Rio_readinitb(&rioIn, connectfd);
	
	Rio_readnb(&rioIn, &rawNetBytes, 4);
	keyUser = ntohs(rawNetBytes);
	printf("Secret Key: %u\n", keyUser);
	
	valid = validate(secretKey, keyUser);

	Rio_readnb(&rioIn, &rawTypeReq, 4);
	typeRequest = ntohs(rawTypeReq);
	printf("Request: %u\n", typeRequest);

	Rio_readnb(&rioIn, input, 80);
	printf("Filename: %s\n", input);
	if(valid == 0){
		switch(typeRequest){
			case 1: 
				retval = mcput(input, connectfd);
				break;
			default:
				retval = -1;
				break;
		}	
	}
	if (retval != 0 && valid != 0)
		printf("FAILURE\n");
	else
		printf("SUCCESS\n");

	return;

};

int main(int argc, char * argv[]){

	int connectfd;
	socklen_t lengthClient = sizeof(struct sockaddr_in);
	struct sockaddr_in clientAddr;
	char type, filename, status;
	struct hostent *hp;
	char *haddrp;

	if(argc < 3){
		printf("Execution Error. Usage './myserver <PORT> <SECRETKEY>'. \n");
		return 1;
	}
	

	int openedfd;
	int port = atoi(argv[1]);
	int secretKey = atoi(argv[2]);
	printf("Inialized Secret Key = %d\n", secretKey);

	//Starts listening for connections on the specified port.
	openedfd = Open_listenfd(port);
	printf("Server waiting for connection... \n");

	//Infinite loop- we are always waiting on a connection.
	while(1){
		
		//Connects to the cliet it request is received
		connectfd = Accept(openedfd, (SA *) &clientAddr, &lengthClient);
	
		//From the echoserver on the csapp website...
		/* determine the domain name and IP address of the client */
		hp = Gethostbyaddr((const char *)&clientAddr.sin_addr.s_addr, 
			   sizeof(clientAddr.sin_addr.s_addr), AF_INET);
		haddrp = inet_ntoa(clientAddr.sin_addr);
		printf("Connected to %s (%s)\n", hp->h_name, haddrp);
	
		//Sends the information to function to determine if valid. If valid, executes.
		application(connectfd, secretKey);
		printf("Closing Connection...\n");
		Close(connectfd);
	}

	
	printf("You shouldn't be here! \n");
	return 0;
}
