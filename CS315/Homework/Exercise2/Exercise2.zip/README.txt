Name: Tristan Basil
Course: CS315 Section 002
Date: 9/8/16
Assignment: Exercise 2

***How to compile and run program***

In order to compile and run the program, the command "make" should be called,
which creates the executable Divisors. This is to the exact specification of
the Divisors game problem assigned for this homework. The regular files can 
be cleaned by calling "make clean".
