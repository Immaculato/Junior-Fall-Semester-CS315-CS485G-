//https://uva.onlinejudge.org/index.php?option=com_onlinejudge&Itemid=8&page=show_problem&problem=508
//https://github.com/s4chin/UVa-Solutions/blob/master/00567.cpp
//minor changes JWJ 11/19/2016
#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
#define oo 10000
#define SIZE 25 //this size is specified in the problem description. For larger input sizes adjustments are needed.
		//for example, a loop that makes SIZE a variable and changes it from 10 to 100 with 10 increments

int fw[SIZE][SIZE];

int main() {
	int count = 1, n, c, t, a, b;
	while(cin>>n) {
		for(int i=0; i<SIZE; i++) for(int j=0; j<SIZE; j++) fw[i][j] = oo;
		for(int i=0; i<SIZE; i++) fw[i][i] = 0;
		for(int i=0; i<n; i++) {
			scanf("%d", &c);
			fw[0][c-1] = 1;
			fw[c-1][0] = 1;
		}
		for(int i=1; i<=SIZE-2; i++) {
			scanf("%d", &n);
			for(int j=0; j<n; j++) {
				scanf("%d", &c);
				fw[i][c-1] = 1;
				fw[c-1][i] = 1;
			}
		}
		for(int k=0; k<SIZE-5; k++)
			for(int i=0; i<SIZE-5; i++)
				for(int j=0; j<SIZE-5; j++)
					fw[i][j] = min(fw[i][j], fw[i][k] + fw[k][j]);
		scanf("%d", &t);
		printf("Test Set #%d:\n", count++);
		while(t--) {
			scanf("%d%d", &a, &b);
			printf("%d to %d: %d\n", a, b, fw[a-1][b-1]);
		}
		printf("\n");
	}
	return 0;
}
